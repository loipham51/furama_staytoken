from urllib.parse import urlencode

from django.conf import settings
from django.db import connection
from django.http import Http404, HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt

from .auth_utils import get_current_user
from .forms import ClaimProfileForm, OTPStartForm
from .models import QRClaim, VoucherType
from .services import (
    enqueue_onchain,
    finish_qr_claim,
    get_or_create_user,
    issue_voucher,
    log_claim_request,
    rate_limit_ok,
    mint_erc1155_now,
    can_user_claim,
)


def _process_claim(request, qr: QRClaim, *, user):
    email = (user.email or "").lower() or None
    phone = user.phone or None
    consent = True
    client_ip = request.META.get("REMOTE_ADDR")
    ua = request.META.get("HTTP_USER_AGENT")

    if not rate_limit_ok(email=email, ip=client_ip):
        log_claim_request(qr, client_ip, ua, email, phone, consent, "rate_limited")
        return render(
            request,
            "claim_start.html",
            {
                "code": qr.code,
                "error": "Bạn thao tác quá nhanh, thử lại sau vài phút.",
            },
            status=429,
        )

    if qr.status != "new":
        log_claim_request(qr, client_ip, ua, email, phone, consent, "used")
        return render(
            request,
            "claim_start.html",
            {
                "code": qr.code,
                "error": "QR đã được sử dụng hoặc không còn hiệu lực.",
            },
            status=409,
        )

    if qr.expires_at and qr.expires_at < timezone.now():
        log_claim_request(qr, client_ip, ua, email, phone, consent, "expired")
        return render(
            request,
            "claim_start.html",
            {
                "code": qr.code,
                "error": "QR đã hết hạn.",
            },
            status=410,
        )

    # Enforce per-user limit
    ok, claimed, limit = can_user_claim(user, qr.voucher_type, amount=1)
    if not ok:
        log_claim_request(qr, client_ip, ua, email, phone, consent, "limit_reached")
        return render(
            request,
            "claim_start.html",
            {
                "code": qr.code,
                "error": f"Bạn đã đạt giới hạn claim ({claimed}/{limit}).",
            },
            status=403,
        )

    # Issue voucher and mint immediately
    from django.db import transaction
    
    try:
        with transaction.atomic():
            wallet = issue_voucher(user, qr.voucher_type, amount=1)
            
            # Mint immediately instead of queuing
            tx_hash = mint_erc1155_now(wallet, qr.voucher_type, amount=1, wait=True)
            
            finish_qr_claim(qr, user)
            log_claim_request(qr, client_ip, ua, email, phone, consent, "ok")
            
            # Store transaction hash in session for success page
            request.session['last_claim_tx_hash'] = tx_hash
            
    except Exception as exc:
        log_claim_request(qr, client_ip, ua, email, phone, consent, f"mint_failed: {str(exc)}")
        return render(
            request,
            "claim_start.html",
            {
                "code": qr.code,
                "error": f"Không thể mint voucher: {str(exc)}",
            },
            status=500,
        )

    return HttpResponseRedirect(reverse("claim_done", args=[qr.code]))

def _voucher_display(qr: QRClaim):
    voucher = qr.voucher_type
    if not voucher:
        return {
            "title": "StayToken voucher",
            "subtitle": "Bring this QR to Furama staff to redeem your benefit.",
            "value": "",
        }
    subtitle = (voucher.description or "").splitlines()[0].strip() if voucher.description else "Enjoy exclusive perks at Furama Resort"
    return {
        "title": voucher.name or voucher.slug,
        "subtitle": subtitle,
        "value": getattr(voucher, "face_value_display", None)
        or getattr(voucher, "face_value", None)
        or getattr(voucher, "value_text", None)
        or "",
    }


def _render_email_form(request, qr: QRClaim, form: OTPStartForm, *, message: str | None = None):
    meta = _voucher_display(qr)
    return render(
        request,
        "claim_guest_email.html",
        {
            "code": qr.code,
            "form": form,
            "voucher_title": meta["title"],
            "voucher_subtitle": meta["subtitle"],
            "voucher_value": meta["value"],
            "error": message,
        },
    )


def _needs_profile(user) -> bool:
    if not user:
        return False
    name = (user.full_name or "").strip().lower()
    placeholder = name.startswith("khach furama") or name.startswith("guest furama")
    return not name or placeholder or not (user.phone and user.phone.strip())


def _render_profile_form(
    request,
    qr: QRClaim,
    form: ClaimProfileForm,
    *,
    status_code: int = 200,
    message: str | None = None,
    user_email: str | None = None,
):
    meta = _voucher_display(qr)
    return render(
        request,
        "claim_guest_form.html",
        {
            "code": qr.code,
            "form": form,
            "voucher_title": meta["title"],
            "voucher_subtitle": meta["subtitle"],
            "voucher_value": meta["value"],
            "error": message,
            "user_email": user_email,
        },
        status=status_code,
    )


def _refresh_user_profile(user, *, full_name: str | None, email: str | None, phone: str | None):
    updates = []
    params = []

    if full_name and full_name.strip() and (user.full_name or "").strip() != full_name.strip():
        updates.append("full_name = %s")
        params.append(full_name.strip())
        user.full_name = full_name.strip()

    if email and email.strip() and (user.email or "").lower().strip() != email.lower().strip():
        updates.append("email = %s")
        params.append(email.lower().strip())
        user.email = email.lower().strip()

    if phone and phone.strip() and (user.phone or "").strip() != phone.strip():
        updates.append("phone = %s")
        params.append(phone.strip())
        user.phone = phone.strip()

    if not updates:
        return user

    updates.append("updated_at = NOW()")
    params.append(str(user.id))
    sql = "UPDATE app_user SET " + ", ".join(updates) + " WHERE id = %s"
    with connection.cursor() as cur:
        cur.execute(sql, params)
    return user


@require_http_methods(["GET"])
    def claim_start(request, code: str):
        try:
        qr = QRClaim.objects.get(code=code)
    except QRClaim.DoesNotExist:
        raise Http404("QR không hợp lệ")

    user = get_current_user(request)
    if user:
        if not _needs_profile(user):
            return _process_claim(request, qr, user=user)
        form = ClaimProfileForm(initial={"full_name": user.full_name or "", "phone": user.phone or ""})
        return _render_profile_form(request, qr, form, user_email=user.email)

    form = OTPStartForm(initial={"next": request.get_full_path()})
    return _render_email_form(request, qr, form)

@require_http_methods(["POST"])
def claim_submit(request, code: str):
    try:
        qr = QRClaim.objects.get(code=code)
    except QRClaim.DoesNotExist:
        raise Http404("QR không hợp lệ")

    user = get_current_user(request)
    if not user:
        login_url = reverse("auth_start")
        next_param = urlencode({"next": request.get_full_path()})
        return HttpResponseRedirect(f"{login_url}?{next_param}")

    if _needs_profile(user):
        form = ClaimProfileForm(request.POST)
        if not form.is_valid():
            return _render_profile_form(request, qr, form, status_code=400, user_email=user.email)

        data = form.cleaned_data
        user = _refresh_user_profile(
            user,
            full_name=data["full_name"],
            email=user.email,
            phone=data.get("phone"),
        )

    return _process_claim(request, qr, user=user)

@require_http_methods(["POST"])  # JSON API: claim by slug and mint now
def claim_mint_now(request, slug: str):
    user = get_current_user(request)
    if not user:
        return JsonResponse({"ok": False, "error": "AUTH_REQUIRED"}, status=401)

    try:
        voucher = VoucherType.objects.get(slug=slug, active=True)
    except VoucherType.DoesNotExist:
        return JsonResponse({"ok": False, "error": "VOUCHER_NOT_FOUND"}, status=404)

    ok, claimed, limit = can_user_claim(user, voucher, amount=1)
    if not ok:
        return JsonResponse({"ok": False, "error": "LIMIT_REACHED", "claimed": claimed, "limit": limit}, status=403)

    # Issue off-chain balance and mint on-chain in one flow
    from django.db import transaction
    
    # Validate config before attempting mint
    if not settings.ST_RPC_URL or not settings.ST_ERC1155_SIGNER or not settings.ST_DEFAULT_CONTRACT:
        return JsonResponse({"ok": False, "error": "CONFIG_INVALID", "detail": "Blockchain configuration incomplete"}, status=500)
    
    try:
        with transaction.atomic():
            wallet = issue_voucher(user, voucher, amount=1)
            
            # Debug info
            contract_addr = voucher.erc1155_contract or settings.ST_DEFAULT_CONTRACT
            token_id = int(voucher.token_id)
            wallet_addr = wallet.address_hex
            
            print(f"DEBUG: contract={contract_addr}, token_id={token_id}, wallet={wallet_addr}")
            print(f"DEBUG: signer_key starts with: {settings.ST_ERC1155_SIGNER[:10]}...")
            
            tx_hash = mint_erc1155_now(wallet, voucher, amount=1, wait=True)
    except Exception as exc:
        import traceback
        print(f"DEBUG: Full error: {exc}")
        print(f"DEBUG: Traceback: {traceback.format_exc()}")
        return JsonResponse({"ok": False, "error": "MINT_FAILED", "detail": str(exc)}, status=500)

    return JsonResponse({
        "ok": True,
        "wallet_address": wallet.address_hex,
        "tx_hash": tx_hash,
        "explorer": (settings.ST_EXPLORER_TX_PREFIX + tx_hash) if settings.ST_EXPLORER_TX_PREFIX else None,
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_test_claim_mint(request):
    """
    Test API để test qua các bước claim_start, claim_submit, claim_done
    POST /api/test/claim-mint
    Body: {
        "email": "test@example.com",
        "full_name": "Test User", 
        "phone": "0123456789",
        "voucher_slug": "spa-30off-2025"
    }
    """
    import json
    import uuid
    from django.utils import timezone
    from django.db import connection
    from .models import AppUser, QRClaim
    
    results = {
        "steps": [],
        "final_result": None,
        "errors": [],
        "qr_code": None
    }
    
    def add_step(step_name, success, data=None, error=None):
        results["steps"].append({
            "step": step_name,
            "success": success,
            "data": data,
            "error": error
        })
        if error:
            results["errors"].append(f"{step_name}: {error}")
    
    try:
        # Parse JSON data
        try:
            if hasattr(request, 'json'):
                data = request.json
            else:
                data = json.loads(request.body.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JsonResponse({
                "ok": False,
                "error": "INVALID_JSON",
                "detail": "Unable to parse JSON data"
            }, status=400)

        email = data.get("email", "").strip().lower()
        full_name = data.get("full_name", "").strip()
        phone = data.get("phone", "").strip()
        voucher_slug = data.get("voucher_slug", "").strip()
        
        if not email or not voucher_slug:
            return JsonResponse({
                "ok": False,
                "error": "MISSING_FIELDS",
                "detail": "email and voucher_slug are required"
            }, status=400)

        # Step 1: Tìm voucher
        try:
            voucher = VoucherType.objects.get(slug=voucher_slug, active=True)
            add_step("find_voucher", True, {
                "voucher_name": voucher.name,
                "voucher_slug": voucher.slug,
                "token_id": voucher.token_id
            })
        except VoucherType.DoesNotExist:
            add_step("find_voucher", False, error=f"Voucher '{voucher_slug}' not found")
            return JsonResponse({
                "ok": False,
                "error": "VOUCHER_NOT_FOUND",
                "detail": f"Voucher '{voucher_slug}' not found or inactive",
                "results": results
            }, status=404)

        # Step 2: Tạo user
        try:
            user = AppUser.objects.filter(email=email).first()
            if not user:
                new_id = uuid.uuid4()
                with connection.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO app_user (id, email, phone, full_name, is_active, created_at, updated_at)
                        VALUES (%s, %s, %s, %s, TRUE, NOW(), NOW())
                        """,
                        [str(new_id), email, phone or None, full_name or "Test User"],
                    )
                user = AppUser.objects.get(id=new_id)
            
            add_step("create_user", True, {
                "user_id": str(user.id),
                "user_email": user.email
            })
        except Exception as e:
            add_step("create_user", False, error=str(e))
            return JsonResponse({
                "ok": False,
                "error": "USER_CREATION_FAILED",
                "detail": str(e),
                "results": results
            }, status=500)

        # Step 3: Tạo QR Claim (giả lập claim_start)
        try:
            qr_code = f"test_{uuid.uuid4().hex[:8]}"
            now = timezone.now()
            qr_claim = QRClaim.objects.create(
                code=qr_code,
                voucher_type=voucher,
                status="new",
                expires_at=now + timezone.timedelta(days=30),
                created_at=now
            )
            results["qr_code"] = qr_code
            add_step("create_qr_claim", True, {
                "qr_code": qr_code,
                "qr_claim_id": str(qr_claim.id)
            })
        except Exception as e:
            add_step("create_qr_claim", False, error=str(e))
            return JsonResponse({
                "ok": False,
                "error": "QR_CREATION_FAILED",
                "detail": str(e),
                "results": results
            }, status=500)

        # Step 4: Simulate claim_start
        try:
            # Tạo fake request object để test claim_start
            class FakeRequest:
                def __init__(self, user):
                    self.user = user
                    self.session = {}
                    self.META = {
                        "REMOTE_ADDR": "127.0.0.1",
                        "HTTP_USER_AGENT": "TEST_API"
                    }
                    self.method = "GET"
                
                def get_full_path(self):
                    return f"/claim/{qr_code}/"
            
            fake_request = FakeRequest(user)
            
            # Test claim_start logic (không render template)
            try:
                qr = QRClaim.objects.get(code=qr_code)
                current_user = user
                
                if current_user:
                    # Simulate _needs_profile check
                    name = (current_user.full_name or "").strip().lower()
                    placeholder = name.startswith("khach furama") or name.startswith("guest furama")
                    needs_profile = not name or placeholder or not (current_user.phone and current_user.phone.strip())
                    
                    if not needs_profile:
                        # User profile is complete, can proceed to claim
                        add_step("claim_start", True, {
                            "user_profile_complete": True,
                            "can_proceed_to_claim": True
                        })
                    else:
                        add_step("claim_start", True, {
                            "user_profile_complete": False,
                            "needs_profile_update": True
                        })
                else:
                    add_step("claim_start", False, error="No user found")
                    
            except QRClaim.DoesNotExist:
                add_step("claim_start", False, error="QR Claim not found")
                
        except Exception as e:
            add_step("claim_start", False, error=str(e))

        # Step 5: Simulate claim_submit (process claim)
        try:
            # Simulate _process_claim logic
            email_check = (user.email or "").lower() or None
            phone_check = user.phone or None
            consent = True
            client_ip = "127.0.0.1"
            ua = "TEST_API"

            # Check rate limiting
            if not rate_limit_ok(email=email_check, ip=client_ip):
                add_step("claim_submit", False, error="Rate limited")
                return JsonResponse({
                    "ok": False,
                    "error": "RATE_LIMITED",
                    "results": results
                }, status=429)

            if qr_claim.status != "new":
                add_step("claim_submit", False, error="QR already used")
                return JsonResponse({
                    "ok": False,
                    "error": "QR_USED",
                    "results": results
                }, status=409)

            if qr_claim.expires_at and qr_claim.expires_at < timezone.now():
                add_step("claim_submit", False, error="QR expired")
                return JsonResponse({
                    "ok": False,
                    "error": "QR_EXPIRED",
                    "results": results
                }, status=410)

            # Check user limits
            ok, claimed, limit = can_user_claim(user, voucher, amount=1)
            if not ok:
                add_step("claim_submit", False, error=f"Limit reached: {claimed}/{limit}")
                return JsonResponse({
                    "ok": False,
                    "error": "LIMIT_REACHED",
                    "claimed": claimed,
                    "limit": limit,
                    "results": results
                }, status=403)

            add_step("claim_submit", True, {
                "rate_limit_ok": True,
                "qr_status_ok": True,
                "user_limits_ok": True,
                "claimed_count": claimed,
                "limit": limit
            })
            
        except Exception as e:
            add_step("claim_submit", False, error=str(e))

        # Step 6: Test actual minting (issue_voucher + mint_erc1155_now)
        try:
            from django.db import transaction
            
            with transaction.atomic():
                wallet = issue_voucher(user, voucher, amount=1)
                add_step("issue_voucher", True, {
                    "wallet_id": str(wallet.id),
                    "wallet_address": wallet.address_hex
                })
                
                # Debug blockchain info before minting
                contract_addr = voucher.erc1155_contract or settings.ST_DEFAULT_CONTRACT
                token_id = int(voucher.token_id)
                wallet_addr = wallet.address_hex
                
                debug_info = {
                    "contract_address": contract_addr,
                    "token_id": token_id,
                    "wallet_address": wallet_addr,
                    "rpc_url": settings.ST_RPC_URL,
                    "signer_address": "0x" + settings.ST_ERC1155_SIGNER[-40:] if len(settings.ST_ERC1155_SIGNER) >= 40 else "invalid",
                    "chain_id": settings.ST_CHAIN_ID
                }
                add_step("blockchain_debug", True, debug_info)
                
                # Try minting with detailed error handling
                try:
                    tx_hash = mint_erc1155_now(wallet, voucher, amount=1, wait=True)
                    add_step("mint_erc1155", True, {
                        "tx_hash": tx_hash,
                        "explorer": (settings.ST_EXPLORER_TX_PREFIX + tx_hash) if settings.ST_EXPLORER_TX_PREFIX else None
                    })
                    
                    # Finish QR claim
                    finish_qr_claim(qr_claim, user)
                    add_step("finish_qr_claim", True, {
                        "qr_status": "completed"
                    })
                    
                except Exception as mint_error:
                    # Detailed mint error analysis
                    error_detail = str(mint_error)
                    add_step("mint_erc1155", False, error=error_detail)
                    
                    # Analyze common mint errors
                    error_analysis = []
                    if "execution reverted" in error_detail:
                        error_analysis.append("Contract execution failed - possible causes:")
                        error_analysis.append("• Signer doesn't have MINTER role")
                        error_analysis.append("• Token ID doesn't exist")
                        error_analysis.append("• Wallet has no ETH for gas")
                        error_analysis.append("• Contract not properly configured")
                    
                    if "insufficient funds" in error_detail.lower():
                        error_analysis.append("• Wallet has insufficient ETH for gas fees")
                    
                    if "access denied" in error_detail.lower():
                        error_analysis.append("• Signer doesn't have permission to mint")
                    
                    return JsonResponse({
                        "ok": False,
                        "error": "MINT_FAILED",
                        "detail": error_detail,
                        "error_analysis": error_analysis,
                        "debug_info": debug_info,
                        "results": results
                    }, status=500)
                
        except Exception as e:
            add_step("mint_process", False, error=str(e))
            return JsonResponse({
                "ok": False,
                "error": "MINT_FAILED",
                "detail": str(e),
                "results": results
            }, status=500)

        # Step 7: Simulate claim_done
        try:
            # Get final wallet info
            from .models import Wallet
            wallet = Wallet.objects.filter(user=user, chain_id=settings.ST_CHAIN_ID).first()
            
            add_step("claim_done", True, {
                "wallet_address": wallet.address_hex if wallet else None,
                "tx_hash": tx_hash,
                "explorer": (settings.ST_EXPLORER_TX_PREFIX + tx_hash) if settings.ST_EXPLORER_TX_PREFIX else None
            })
            
        except Exception as e:
            add_step("claim_done", False, error=str(e))

        # Final success
        results["final_result"] = "SUCCESS"
        return JsonResponse({
            "ok": True,
            "message": "All claim steps completed successfully",
            "results": results,
            "voucher_name": voucher.name,
            "user_email": user.email,
            "wallet_address": wallet.address_hex,
            "tx_hash": tx_hash,
            "qr_code": qr_code
        })

    except Exception as e:
        import traceback
        add_step("unexpected_error", False, error=str(e))
        results["final_result"] = "ERROR"
        
        return JsonResponse({
            "ok": False,
            "error": "INTERNAL_ERROR",
            "detail": str(e),
            "results": results
        }, status=500)



def claim_done(request, code: str):
    try:
        qr = QRClaim.objects.get(code=code)
    except QRClaim.DoesNotExist:
        raise Http404
    user = qr.used_by_user
    wallet = None
    if user:
        from .models import Wallet
        wallet = Wallet.objects.filter(user=user, chain_id=settings.ST_CHAIN_ID).first()
    
    # Get transaction hash from session
    tx_hash = request.session.pop('last_claim_tx_hash', None)
    explorer_url = None
    if tx_hash and settings.ST_EXPLORER_TX_PREFIX:
        explorer_url = settings.ST_EXPLORER_TX_PREFIX + tx_hash
    
    # Tạo URL QR ví để hiển thị trong template claim_success.html
    wallet_addr = wallet.address_hex if wallet else ""
    qr_png_url = reverse("qr_wallet_png", kwargs={"addr": wallet_addr[2:]}) if wallet_addr else ""
    
    return render(request, "claim_success.html", {
        "wallet_address": wallet_addr,
        "qr_png_url": qr_png_url,
        "tx_hash": tx_hash,
        "explorer_url": explorer_url,
        "voucher_name": qr.voucher_type.name if qr.voucher_type else "StayToken voucher"
    })
