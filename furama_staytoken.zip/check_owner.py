#!/usr/bin/env python3
"""
Script kiểm tra owner của contract
"""

import os
import sys
import django
from web3 import Web3

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'furama_staytoken.settings')
django.setup()

from django.conf import settings

def check_contract_owner():
    """Kiểm tra owner của contract"""
    print("🔍 CHECKING CONTRACT OWNER")
    print("=" * 50)
    
    # Contract addresses
    contract1 = "0xD8429E46b46181F2B0C47057e7c29206AD3BEfC9"  # Settings contract
    contract2 = "0x38D0eD202a5817a2DeD39a0d5dA040463dAe7D08"  # Voucher contract
    signer = "0x5c2c24D11D619b7cF0A65A2Bb5EF12775DD3Bc37"
    
    try:
        w3 = Web3(Web3.HTTPProvider(settings.ST_RPC_URL))
        
        if not w3.is_connected():
            print("❌ Web3 connection failed")
            return
        
        print(f"👤 Signer Address: {signer}")
        print(f"📄 Contract 1 (Settings): {contract1}")
        print(f"📄 Contract 2 (Voucher): {contract2}")
        print()
        
        owner1 = None
        owner2 = None
        
        # Check Contract 1 (Settings)
        print("🔍 CHECKING CONTRACT 1 (Settings)")
        print("-" * 30)
        try:
            # Call owner() function
            owner_encoded = w3.keccak(text="owner()")[:4]  # First 4 bytes of keccak256("owner()")
            result = w3.eth.call({
                'to': contract1,
                'data': owner_encoded
            })
            if len(result.hex()) >= 66:
                owner1 = w3.to_checksum_address('0x' + result.hex()[26:66])  # Remove first 6 bytes (0x + 24 zeros)
                print(f"✅ Contract 1 Owner: {owner1}")
                print(f"🔍 Signer is Owner: {'✅ YES' if owner1.lower() == signer.lower() else '❌ NO'}")
            else:
                print(f"❌ Invalid owner response: {result.hex()}")
        except Exception as e:
            print(f"❌ Error checking contract 1: {e}")
        
        print()
        
        # Check Contract 2 (Voucher)
        print("🔍 CHECKING CONTRACT 2 (Voucher)")
        print("-" * 30)
        try:
            # Call owner() function
            owner_encoded = w3.keccak(text="owner()")[:4]
            result = w3.eth.call({
                'to': contract2,
                'data': owner_encoded
            })
            if len(result.hex()) >= 66:
                owner2 = w3.to_checksum_address('0x' + result.hex()[26:66])
                print(f"✅ Contract 2 Owner: {owner2}")
                print(f"🔍 Signer is Owner: {'✅ YES' if owner2.lower() == signer.lower() else '❌ NO'}")
            else:
                print(f"❌ Invalid owner response: {result.hex()}")
        except Exception as e:
            print(f"❌ Error checking contract 2: {e}")
        
        print()
        print("🔧 RECOMMENDATIONS:")
        print("-" * 20)
        
        # Analyze results
        if owner1 and owner1.lower() == signer.lower():
            print("✅ Signer is owner of Contract 1 - can mint")
        elif owner1:
            print("❌ Signer is NOT owner of Contract 1 - cannot mint")
            print(f"   Need to transfer ownership to: {signer}")
        
        if owner2 and owner2.lower() == signer.lower():
            print("✅ Signer is owner of Contract 2 - can mint")
        elif owner2:
            print("❌ Signer is NOT owner of Contract 2 - cannot mint")
            print(f"   Need to transfer ownership to: {signer}")
        
        print()
        print("📋 NEXT STEPS:")
        print("1. If signer is NOT owner, transfer ownership in Remix")
        print("2. Or update settings to use the contract where signer IS owner")
        print("3. Or modify contract to use MINTER_ROLE instead of onlyOwner")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    check_contract_owner()
